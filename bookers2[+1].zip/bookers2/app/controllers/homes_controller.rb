class HomesController < ApplicationController
  def top
  end
  
  def about
  end
end
