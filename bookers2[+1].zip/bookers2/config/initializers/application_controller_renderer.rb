# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '8a62f6bb2d6f91618786bd1e3ff96ccdd85b4f91e0b63cecb4838a10890f0bf3c7243ef48037d64082b50e81138d5f11f739371fbe5916ee388a2c72cf655ffc'
